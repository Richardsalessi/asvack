

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 sm:px-6 py-8 text-zinc-900 dark:text-zinc-100">

    
    <div class="mb-6">
        <h1 class="text-2xl sm:text-3xl font-semibold">Orden #<?php echo e($orden->id); ?></h1>
        <div class="text-sm opacity-70">
            Creada: <?php echo e($orden->created_at?->format('d/m/Y H:i')); ?> •
            Estado pago:
            <span class="font-medium">
                <?php echo e(ucfirst($orden->estado ?? '—')); ?>

            </span> •
            Total:
            <span class="font-medium">
                $<?php echo e(number_format((float)($orden->total ?? 0), 0, ',', '.')); ?>

            </span>
        </div>
    </div>

    
    <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 overflow-hidden mb-6">
        <div class="px-4 py-3 border-b border-zinc-200 dark:border-zinc-700">
            <h2 class="text-lg font-semibold">Productos</h2>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-zinc-50 dark:bg-zinc-900/40">
                <tr class="text-left">
                    <th class="px-4 py-3">Producto</th>
                    <th class="px-4 py-3 text-center">Cant.</th>
                    <th class="px-4 py-3 text-right">Precio</th>
                    <th class="px-4 py-3 text-right">Subtotal</th>
                </tr>
                </thead>
                <tbody class="divide-y divide-zinc-200 dark:divide-zinc-700">
                <?php $__currentLoopData = ($orden->detalles ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Precio unitario "congelado" guardado en el detalle
                        // Ajusta los nombres si en tu BD son distintos
                        $unit = $d->precio_unitario
                            ?? $d->precio
                            ?? $d->valor_unitario
                            ?? 0;

                        $cant = (int)($d->cantidad ?? 1);

                        // Si existe subtotal por línea en la BD, úsalo; si no, calcúlalo.
                        $linea = $d->subtotal ?? ($unit * $cant);
                    ?>
                    <tr>
                        <td class="px-4 py-3">
                            <?php echo e($d->producto->nombre ?? ($d->nombre_producto ?? '—')); ?>

                        </td>
                        <td class="px-4 py-3 text-center">
                            <?php echo e($cant); ?>

                        </td>
                        <td class="px-4 py-3 text-right">
                            $<?php echo e(number_format((float)$unit, 0, ',', '.')); ?>

                        </td>
                        <td class="px-4 py-3 text-right">
                            $<?php echo e(number_format((float)$linea, 0, ',', '.')); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="px-4 py-3 border-t border-zinc-200 dark:border-zinc-700 text-right">
            <div>Subtotal: $<?php echo e(number_format((float)($orden->subtotal ?? 0), 0, ',', '.')); ?></div>
            <div>Envío: $<?php echo e(number_format((float)($orden->envio ?? 0), 0, ',', '.')); ?></div>
            <div class="text-lg font-semibold">Total: $<?php echo e(number_format((float)($orden->total ?? 0), 0, ',', '.')); ?></div>
        </div>
    </div>

    
    <?php
        $dir = data_get($orden->datos_envio, 'envio');
    ?>
    <?php if($dir): ?>
        <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 p-4 mb-6">
            <h2 class="text-lg font-semibold mb-2">Dirección de envío</h2>
            <div class="text-sm">
                <?php echo e(trim(($dir['nombre'] ?? '').' '.($dir['apellidos'] ?? ''))); ?><br>
                <?php echo e($dir['direccion'] ?? ''); ?><br>
                <?php echo e(trim(($dir['ciudad'] ?? '').', '.($dir['departamento'] ?? ''))); ?>

            </div>
        </div>
    <?php endif; ?>

    
    
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
    <div class="mt-8 p-6 border rounded-xl bg-white dark:bg-zinc-900 dark:border-zinc-700">
        <h2 class="text-lg font-semibold mb-4">📦 Gestión de Envío</h2>

        
        <form method="POST" action="<?php echo e(route('admin.envios.configurar', $orden->id)); ?>" class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <?php echo csrf_field(); ?>
            <div>
                <label class="text-sm opacity-80">Transportadora</label>
                <input type="text" name="transportadora"
                       value="<?php echo e(old('transportadora', $orden->envioRegistro->transportadora ?? '')); ?>"
                       class="w-full mt-1 rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800">
            </div>
            <div>
                <label class="text-sm opacity-80">Número de guía</label>
                <input type="text" name="numero_guia"
                       value="<?php echo e(old('numero_guia', $orden->envioRegistro->numero_guia ?? '')); ?>"
                       class="w-full mt-1 rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800">
            </div>
            <div>
                <label class="text-sm opacity-80">Tipo de envío</label>
                <select name="tipo_envio"
                        class="w-full mt-1 rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800">
                    <?php
                        $tipos = [
                            'pagado_cliente'   => 'Pagado por el cliente',
                            'asumido_empresa'  => 'Asumido por la empresa',
                            'contraentrega'    => 'Contraentrega',
                        ];
                    ?>
                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(($orden->envioRegistro->tipo_envio ?? '') === $k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="text-sm opacity-80">Costo de envío (COP)</label>
                <input type="number" name="costo_envio" min="0"
                       value="<?php echo e(old('costo_envio', $orden->envioRegistro->costo_envio ?? 0)); ?>"
                       class="w-full mt-1 rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800">
            </div>
            <div class="md:col-span-2">
                <label class="text-sm opacity-80">Notas internas</label>
                <textarea name="notas" rows="2"
                          class="w-full mt-1 rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800"><?php echo e(old('notas', $orden->envioRegistro->notas ?? '')); ?></textarea>
            </div>

            <div class="md:col-span-2">
                <button type="submit"
                        class="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 transition">
                    💾 Guardar datos de envío
                </button>
            </div>
        </form>

        
        <?php if($orden->envioRegistro): ?>
            <form method="POST" action="<?php echo e(route('admin.envios.estado', $orden->id)); ?>" class="flex flex-wrap items-center gap-3">
                <?php echo csrf_field(); ?>
                <label class="text-sm opacity-80">Estado actual:</label>
                <select name="estado_envio" class="rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800">
                    <?php $__currentLoopData = ['pendiente' => 'Pendiente', 'en_transito' => 'En tránsito', 'entregado' => 'Entregado', 'devuelto' => 'Devuelto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(($orden->envioRegistro->estado_envio ?? '') === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit"
                        class="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-500 transition">
                    🚚 Actualizar estado
                </button>
            </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\asvack\resources\views/admin/ordenes/show.blade.php ENDPATH**/ ?>