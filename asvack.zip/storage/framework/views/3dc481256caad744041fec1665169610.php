

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 sm:px-6 py-8 text-zinc-900 dark:text-zinc-100">

    
    <div class="mb-4">
        <h1 class="text-2xl sm:text-3xl font-semibold">Pedidos & Envíos</h1>

        
        <?php
            $chips = [];
            if (!empty($q))             $chips['q'] = "#/ref/guía: $q";
            if (!empty($estado))       $chips['estado'] = "Pago: ".ucfirst($estado);
            if (!empty($estadoEnvio))  $chips['estado_envio'] = "Envío: ".str_replace('_',' ', ucfirst($estadoEnvio));
            if (!empty($desde))        $chips['desde'] = "Desde: $desde";
            if (!empty($hasta))        $chips['hasta'] = "Hasta: $hasta";
        ?>
        <?php if(count($chips)): ?>
            <div class="mt-2 flex flex-wrap gap-2">
                <?php $__currentLoopData = $chips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-flex items-center gap-2 px-2 py-1 text-xs rounded-full bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700">
                        <?php echo e($label); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('ordenes.admin')); ?>"
                   class="text-xs underline opacity-80 hover:opacity-100">Limpiar</a>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if(isset($stats)): ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 p-4">
            <div class="text-xs opacity-70">Pendientes</div>
            <div class="text-2xl font-semibold"><?php echo e($stats['pendientes'] ?? 0); ?></div>
        </div>
        <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 p-4">
            <div class="text-xs opacity-70">Pagadas</div>
            <div class="text-2xl font-semibold"><?php echo e($stats['pagadas'] ?? 0); ?></div>
        </div>
        <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 p-4">
            <div class="text-xs opacity-70">En tránsito</div>
            <div class="text-2xl font-semibold"><?php echo e($stats['en_transito'] ?? 0); ?></div>
        </div>
        <div class="rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 p-4">
            <div class="text-xs opacity-70">Entregados</div>
            <div class="text-2xl font-semibold"><?php echo e($stats['entregados'] ?? 0); ?></div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="rounded-2xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 border-zinc-200 overflow-hidden">
        <div class="px-4 py-3 border-b border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
            <h2 class="text-lg font-semibold">Órdenes recientes</h2>

            
            <div class="flex items-center gap-2">
                <button type="button" id="btnOpenFilters"
                        class="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-emerald-600 text-white hover:bg-emerald-500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M3 5h18v2H3V5Zm4 6h10v2H7v-2Zm-2 6h14v2H5v-2Z"/></svg>
                    Filtros
                </button>
                <a href="<?php echo e(route('ordenes.admin')); ?>"
                   class="px-3 py-2 rounded-md bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600">
                    Limpiar
                </a>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-zinc-50 dark:bg-zinc-900/40">
                    <tr class="text-left">
                        <th class="px-4 py-3">#</th>
                        <th class="px-4 py-3">Cliente</th>
                        <th class="px-4 py-3">Total</th>
                        <th class="px-4 py-3">Estado pago</th>
                        <th class="px-4 py-3">Estado envío</th>
                        <th class="px-4 py-3">Ref. pago</th>
                        <th class="px-4 py-3">Transp./Guía</th>
                        <th class="px-4 py-3 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-zinc-200 dark:divide-zinc-700">
                    <?php $__empty_1 = true; $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $env = $orden->envioRegistro; ?>
                        <tr>
                            <td class="px-4 py-3 font-medium">#<?php echo e($orden->id); ?></td>
                            <td class="px-4 py-3">
                                <?php echo e($orden->user?->name ?? '—'); ?>

                                <div class="text-xs opacity-70"><?php echo e($orden->created_at?->format('d/m/Y H:i')); ?></div>
                            </td>
                            <td class="px-4 py-3 font-semibold">
                                $<?php echo e(number_format($orden->total ?? 0, 0, ',', '.')); ?>

                            </td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'bg-yellow-100 text-yellow-800' => $orden->estado === 'pendiente',
                                        'bg-emerald-100 text-emerald-800' => $orden->estado === 'pagada',
                                        'bg-red-100 text-red-800' => in_array($orden->estado, ['rechazada','cancelada']),
                                        'bg-zinc-100 text-zinc-800' => !in_array($orden->estado, ['pendiente','pagada','rechazada','cancelada']),
                                    ]); ?>"
                                "><?php echo e(ucfirst($orden->estado ?? '—')); ?></span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'bg-zinc-100 text-zinc-800' => !($env?->estado_envio),
                                        'bg-blue-100 text-blue-800' => $env?->estado_envio === 'en_transito',
                                        'bg-emerald-100 text-emerald-800' => $env?->estado_envio === 'entregado',
                                        'bg-yellow-100 text-yellow-800' => $env?->estado_envio === 'pendiente',
                                        'bg-red-100 text-red-800' => $env?->estado_envio === 'devuelto',
                                    ]); ?>"
                                "><?php echo e($env?->estado_envio ? str_replace('_',' ', ucfirst($env->estado_envio)) : '—'); ?></span>
                            </td>
                            <td class="px-4 py-3">
                                <?php $ref = $orden->ultimo_invoice ?? $orden->ref_epayco ?? null; ?>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs select-all"><?php echo e($ref ?? '—'); ?></span>
                                    <?php if($ref): ?>
                                        <button type="button" class="text-xs px-2 py-1 rounded border border-zinc-300 dark:border-zinc-600 hover:bg-zinc-100 dark:hover:bg-zinc-700"
                                                onclick="navigator.clipboard?.writeText('<?php echo e($ref); ?>')">
                                            Copiar
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-4 py-3">
                                <div class="text-xs">
                                    <div class="opacity-80"><?php echo e($env?->transportadora ?? '—'); ?></div>
                                    <div class="opacity-60"><?php echo e($env?->numero_guia ?? ''); ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-right">
                                <a href="<?php echo e(route('ordenes.show', $orden->id)); ?>"
                                   class="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-emerald-600 text-white hover:bg-emerald-500 transition">
                                    Gestionar
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M13.172 12 8.222 7.05l1.414-1.414L16 12l-6.364 6.364-1.414-1.414z"/></svg>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-4 py-6 text-center opacity-70">No hay órdenes para mostrar.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="px-4 py-3 border-t border-zinc-200 dark:border-zinc-700">
            <?php echo e($ordenes->links()); ?>

        </div>
    </div>
</div>




<div id="filtersModal" class="fixed inset-0 z-50 hidden">
    
    <div class="absolute inset-0 bg-black/40" aria-hidden="true"></div>

    
    <div class="relative h-full w-full flex items-start md:items-center justify-center p-4 md:p-6">
        <div class="w-full max-w-3xl rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 shadow-xl">
            <div class="px-5 py-3 border-b border-zinc-200 dark:border-zinc-700 flex items-center justify-between">
                <h3 class="text-lg font-semibold">Filtrar pedidos</h3>
                <button type="button" id="btnCloseFilters" class="p-2 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800">✕</button>
            </div>

            <form method="GET" class="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="sm:col-span-2">
                    <label class="text-xs opacity-70">Buscar</label>
                    <input type="text" name="q" value="<?php echo e($q ?? ''); ?>"
                           placeholder="#orden, ref, guía, transportadora"
                           class="w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 px-3 py-2">
                </div>

                <div>
                    <label class="text-xs opacity-70">Estado de pago</label>
                    <select name="estado" class="w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 px-3 py-2">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = ['pendiente','pagada','rechazada','cancelada','enviada','entregada']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($e); ?>" <?php if(($estado ?? '') === $e): echo 'selected'; endif; ?>><?php echo e(ucfirst($e)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="text-xs opacity-70">Estado de envío</label>
                    <select name="estado_envio" class="w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 px-3 py-2">
                        <option value="">Todos</option>
                        <?php $__currentLoopData = ['pendiente'=>'Pendiente','en_transito'=>'En tránsito','entregado'=>'Entregado','devuelto'=>'Devuelto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>" <?php if(($estadoEnvio ?? '') === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="text-xs opacity-70">Desde</label>
                    <input type="date" name="desde" value="<?php echo e($desde ?? ''); ?>"
                           class="w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 px-3 py-2">
                </div>
                <div>
                    <label class="text-xs opacity-70">Hasta</label>
                    <input type="date" name="hasta" value="<?php echo e($hasta ?? ''); ?>"
                           class="w-full rounded-md border-zinc-300 dark:border-zinc-700 dark:bg-zinc-800 px-3 py-2">
                </div>

                <div class="sm:col-span-2 flex items-center justify-end gap-2 pt-2">
                    <a href="<?php echo e(route('ordenes.admin')); ?>"
                       class="px-4 py-2 rounded-md bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600">
                        Limpiar
                    </a>
                    <button class="px-4 py-2 rounded-md bg-emerald-600 text-white hover:bg-emerald-500">
                        Aplicar filtros
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    const modal   = document.getElementById('filtersModal');
    const openBtn = document.getElementById('btnOpenFilters');
    const closeBtn= document.getElementById('btnCloseFilters');

    function openModal() {
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }
    function closeModal() {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }

    openBtn?.addEventListener('click', openModal);
    closeBtn?.addEventListener('click', closeModal);

    // Cerrar al hacer click fuera del panel
    modal?.addEventListener('click', (e) => {
        // si el click es en el fondo oscuro, cierra
        if (e.target === modal.querySelector('.absolute.inset-0')) closeModal();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\asvack\resources\views/admin/ordenes/index.blade.php ENDPATH**/ ?>